angular.module('MyRouting',['ngRoute']);
config(function($routeProvider){
    $routeProvider
    .when('/about', {
    templateUrl: 'innerPage/about.html', controller: 'AboutCtrl'}).
    otherwise({redirectTo: '/home'});
})
.controller('AboutCtrl', function ($scope, StateService) {
        $scope.title = 'About Page';
        $scope.body = 'This is the about page body';
     
    });